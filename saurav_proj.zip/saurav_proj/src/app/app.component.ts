import { Component } from '@angular/core';
import { CoreserviceService } from './coreservice.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'elancoproj';
  user: any;
  user2: any;
  res1: any;
  res2: any;
  name3: any;
  boolFlag: boolean = false;
  name2: any;
  boolFlag1: boolean = false;
  tagData: any;
  tabKey12: any;
  tabKey1: any;
  newDta: any;
  newarr: any;
  tabkey13: any;

  constructor(private _CoreserviceService: CoreserviceService) {

    this._CoreserviceService.getCore().subscribe((data: any) => {
      this.user = data
    });

    this._CoreserviceService.getCore2().subscribe((data: any) => {
      this.user2 = data
    });
  }

  onClick(event: any) {
    this.boolFlag = true;
    this._CoreserviceService.getResponce(event).subscribe((data: any) => {
      this.res1 = data;
      this.res1.forEach((element: any) => {
        this.tabKey1 = Object.keys(element)
      });
    });
  }

  fetchSeconData(event: any) {
    this.boolFlag1 = true;
    this.name3 = event.replace(/\s+/g, '%20');
    this._CoreserviceService.getResponce2(this.name3).subscribe((data: any) => {
      this.res2 = data;
      this.res2.forEach((element: any) => {
        this.tabKey12 = Object.keys(element)
        this.tabkey13 = Object.entries(element);
        this.tabkey13 = this.res2.filter((e: any) => e.Tags == this.res2.Tags);
      });
    });
  }

  takeMeBack(event: any) {
    this.boolFlag = event;
    this.boolFlag1 = event;
  }




}
