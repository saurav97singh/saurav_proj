import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CoreserviceService {

  coreStat: any;
  core2: any;
  res1: any;

  constructor(private _http: HttpClient) { }

  getCore() {
    this.coreStat = this._http.get<any>("https://engineering-task.elancoapps.com/api/applications")
    return this.coreStat;
  }

  getCore2() {
    this.core2 = this._http.get<any>("https://engineering-task.elancoapps.com/api/resources")
    return this.core2
  }

  getResponce(name1: string) {
    this.res1 = this._http.get<any>("https://engineering-task.elancoapps.com/api/applications/" + name1);
    return this.res1;
  }
  getResponce2(name2: string) {
    this.res1 = this._http.get<any>("https://engineering-task.elancoapps.com/api/resources/" + name2);
    return this.res1;
  }
}
